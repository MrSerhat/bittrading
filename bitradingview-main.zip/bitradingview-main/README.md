# tradingview-binance-strategy-alert-webhook
TradingView Strategy Alert Webhook that buys and sells crypto with the Binance API

## YouTube tutorial on how to use this code

https://www.youtube.com/watch?v=gMRee2srpe8
